module.exports = {
  extends: 'airbnb-base',
  rules: {},
};
