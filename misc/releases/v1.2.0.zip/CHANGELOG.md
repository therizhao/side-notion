# SideNotion ChangeLog

## v1.2.0

- Fix: Fix screen dimensions of new window
- Chore: Package and release on chrome extension store

## v1.1.2

- Fix: Fix crop image dimensions

## v1.1.1

- Fix: Fix keycode

## v1.1.0

- Feat: Hide video frame crop area

## v1.0.0

- Feat: Capture video frame and paste to notion
- Feat: Custom video frame crop area
