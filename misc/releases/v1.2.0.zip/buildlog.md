# Changelog

- [ ] Fix css for dragging block
- [ ] Store image in local state
- [ ] Screenshot video
- [ ] Send screenshot to notion
- [ ] Can try https://editorjs.io/
- [ ] Background
  - [ ] Trigger when click
- [ ] Add dragger to change width
- [ ] Check Handle exceptions (navigator clipboard)
- [ ] Auto skip cursor to bottom of image
- [ ] Get current cursor position and paste to current cursor position

- [ ] Youtube skip to video start - pause original video start video at same spot
- [ ] Exception handling
- [ ] Make hint ui
- [ ] Error handling when change tab or etc (Make sure both windows are active)
- [ ] Separate window or same screen
- [ ] dont open new notion if alr have one

#EB5757

user test

feedback

## 10 Dec 2021

- [x] Remove clipbaord read write

## 7 Dec 2021

- [x] Hide box
- [x] Show box if just start
- [x] Ask for review
  - [x] https://chrome.google.com/webstore/detail/sidenotion/ihjmeedcmbeapmaagcjpngemnckiooih

## 6 Dec 2021

- [ ] should show box if just start

- [x] Test
- [x] feedback https://docs.google.com/forms/d/e/1FAIpQLSdq6KtGZKvPLN2KBaxyw3D37PidA9EBFAfYUtaR7Vq8mGuZdQ/viewform?usp=sf_link
- [x] Pacakage release

## 5 Dec 2021

- [x] Error handling
  - [x] Try closing the notion window and start a new notetaking session from the video window
- [x] windows ctrl
- [x] draggable frame
  - [x] construct frame with get bounding client rect
  - [x] else just a random position
  - [x] custom capture area
    - [x] cmd shift \
      - [x] show capture area
      - [x] if capture area present
        - [x] set the dimensions to capture area

## 4 Dec 2021

- [x] split window

  - [x] get current desktop dimensions - [x] move current window to left half - [x] open window in right hlaf
        chrome.system.display
        update

- [x] weird signal bug
- [x] dont' open new notion
  - [x] query see if notion exist
- remove iframe
- [ ] update tab id
- [ ] save active window id then get dimension of active tab
      user expeerience when multi window

## 3 Dec 2021

- [x] Hint ui -> Cmd shift ,

- [ ] Show which one in focus
  - [ ] show active video
    - [ ] todo: not sure what is the active video cos everything works in separate windows mode
    - [ ] ctrl for windows
  - [ ] update logo

```
user-select: none;
    transition: opacity 700ms ease 0s, color 700ms ease 0s, transform 200ms ease 0s;
    cursor: pointer;
    opacity: 1;
    position: absolute;
    display: flex;
    align-items: center;
    justify-content: center;
    background: white;
    bottom: 16px;
    right: 16px;
    width: 36px;
    height: 36px;
    border-radius: 100%;
    font-size: 20px;
    box-shadow: rgb(15 15 15 / 10%) 0px 0px 0px 1px, rgb(15 15 15 / 10%) 0px 2px 4px;
    z-index: 101;
    transform: translateX(0px) translateZ(0px);
```

```
position: absolute;
    /* display: flex; */
    /* align-items: center; */
    /* justify-content: center; */
    background: white;
    bottom: 16px;
    right: 16px;
    padding: 6px;
    background: white;
    max-width: calc(100vw - 24px);
    color: rgb(55, 53, 47);
    box-shadow: rgb(15 15 15 / 5%) 0px 0px 0px 1px, rgb(15 15 15 / 10%) 0px 3px 6px, rgb(15 15 15 / 20%) 0px 9px 24px;
    /* width: 300px; */
    border-radius: 3px;
    /* height: 36px; */
    /* border-radius: 100%; */
    /* font-size: 20px; */
    /* box-shadow: rgb(15 15 15 / 10%) 0px 0px 0px 1px, rgb(15 15 15 / 10%) 0px 2px 4px; */
    z-index: 101;
    transform: translateX(0px) translateZ(0px);
    font-familyui-sans-serif, -apple-system, "system-ui", "Segoe UI", Helvetica, "Apple Color Emoji", Arial, sans-serif, "Segoe UI Emoji", "Segoe UI Symbol": ;
    font-size: 14px;
```

```
align-itemscenter
background-attachmentscroll
background-clipborder-box
background-colorrgb(255, 255, 255)
background-imagenone
background-originpadding-box
background-position-x0%
background-position-y0%
background-repeat-x
background-repeat-y
background-sizeauto
border-bottom-left-radius100%
border-bottom-right-radius100%
border-top-left-radius100%
border-top-right-radius100%
bottom16px
box-shadowrgba(15, 15, 15, 0.1) 0px 0px 0px 1px, rgba(15, 15, 15, 0.1) 0px 2px 4px 0px
box-sizingborder-box
colorrgb(55, 53, 47)
cursorpointer
displayflex
fillrgb(55, 53, 47)
font-familyui-sans-serif, -apple-system, "system-ui", "Segoe UI", Helvetica, "Apple Color Emoji", Arial, sans-serif, "Segoe UI Emoji", "Segoe UI Symbol"
font-size20px
height36px
justify-contentcenter
line-height30px
opacity1
outline-colorrgb(55, 53, 47)
outline-stylenone
outline-width0px
positionabsolute
right16px
text-size-adjust100%
transformmatrix(1, 0, 0, 1, 0, 0)
transition-delay0s, 0s, 0s
transition-duration0.7s, 0.7s, 0.2s
transition-propertyopacity, color, transform
transition-timing-functionease, ease, ease
user-selectnone
width36px
z-index101
-webkit-font-smoothingauto
```

## 2 Dec 2021

- [x] Clean up code
- [x] Screenshot with chrome api
- [x] error handler window has to be active

## 30 Nov 2021

- [x] Compatability with all videos
  - [x] Manifest switch on recorder.js for all
  - [x] If not youtube or vimeo
    - [x] create new window with notion
    - [x] activate content.js
    - [x] activate recorder.js
  - [x] See how they create the clone video player

capture with chrome api then crop

```js
v.chrome.tabs.captureVisibleTab(
  { format: 'png' },
  function (e) {
    v.chrome.tabs.getZoom(null, function (r) {
      var i = n.data.devicePixelRatio,
        o = n.data.captureRect.width,
        s = n.data.captureRect.height,
        a = document.createElement('canvas');
      (a.width = Math.ceil(o * i)),
        (a.height = Math.ceil(s * i));
      var u = a.getContext('2d'),
        c = new Image(),
        h =
          n.data.captureRect.left +
          n.data.videoContainerRect.left,
        f =
          n.data.captureRect.top +
          n.data.videoContainerRect.top;
      (c.onload = function () {
        u.drawImage(
          c,
          Math.ceil(h * i),
          Math.ceil(f * i),
          Math.ceil(o * i),
          Math.ceil(s * i),
          0,
          0,
          Math.ceil(o * i),
          Math.ceil(s * i)
        );
        var e = a.toDataURL('image/png', 1);
        t.postMessage({
          action:
            'BACK_TO_CONTENT_sendCaptureImg',
          data: {
            captureImgBase64: e,
            captureTime: n.data.captureTime,
          },
        });
      }),
        (c.src = e);
    });
  }
),
e.abrupt('break', 32)
);
```

## 29 Nov 2021

- [x] Fix multiple iframes race condition
- [x] Support vimeo

## 28 Nov 2021

- [x] Open video and notion
  - [x] Click button start
  - [x] Click button review
  - [x] Send signal to open new tab with iframe

## 26 Nov 2021

last try

- [x] First take video record
- [x] Next, convert to data string
- [x] Next send over
- [x] Next paste from clipboard or drop handler
- [x] bring your own cloud
- [x] User hint

https://streamable.com

## 25 Nov 2021

- [x] Send video blobs as chunks
  - [x] https://stackoverflow.com/questions/25668998/how-to-pass-a-blob-from-a-chrome-extension-to-a-chrome-app
- [x] Clipboard doesn't accept video
  - [ ] https://stackoverflow.com/questions/68897154/list-of-supported-mime-types-for-clipboard-write
- [ ] Pass pointer to a file to clipboard
- [ ] Current idea is to invoke drag and drop handler
  - [ ] Find last element
  - [ ] ondrop
- [ ] OR send via api request
  - [ ] Ask user to pass the api key
- [ ] OR ask notion ppl
- Event handlers present
  - drag
  - dragend
  - dragenter
  - dragleave

use vimeo to get the data

or use streamable
streamupload() {
code=$(curl --request POST --url https://api.streamable.com/upload --user $STREAMABLEUSER:$STREAMABLEPASSWORD --form file=@"$1" | jq '.shortcode' | perl -pe 's/"//g');
  echo Added https://streamable.com/$code to your clipboard;
echo https://streamable.com/$code | clip.exe;
}

```js
file = new File(['foo'], 'foo.txt', {
  type: 'text/plain',
});
event = document.createEvent('HTMLEvents');
event.initEvent('drop', true, true);
event.dataTransfer = { files: [file] };
elem.dispatchEvent(event);
```

## 24 Nov 2021

- [x] Use this to get the video frames directly
- [x] https://developer.mozilla.org/en-US/docs/Web/Guide/Audio_and_video_manipulation

## 23 Nov 2021

- [ ] Start stop screen recording
  - [ ] Start recording
  - [ ] End recording
  - [ ] Get audio

## 22 Nov 2021

- [x] Paste to notion
  - [x] aste a random text
    - [x] Find chrome extension
      - [x] Paste it -> Write to clipboard
      - [x] https://newbedev.com/why-is-document-execcommand-paste-not-working-in-google-chrome

## 21 Nov 2021

- [x] send screenshot from yotube script to content script

## 20 Nov 2021

- [x] Add an event listener (cmd/ctrl + shift + /)
- [x] Take screenshot

html video -> just use normal video tag
special video use iframe
permissions problem for cross origin access of iframes for authenticated pages

## 19 Nov 2021

- [x] Make manifest file
- [x] Modify html
  - [x] Content script (Modifies web page)
  - [x] CSS fix notion
    - [x] Width is not right
  - [x] Add video
- [x] Load a video on the side

## 18 Nov 2021

- [ ] Use a chrome extension
  - [ ] OPen notion
  - [ ] Embed video at the side
  - [ ] Take screenshot
  - [ ] Run a function
    - [ ] Send the same signal
    - [ ] Manually call the paste event listener in notion
      - [ ] getEventListeners(document).paste
      - [ ] https://developer.chrome.com/docs/extensions/mv3/declare_permissions/ (use clipboard))
    - [ ] Callt eh paste event handler
      - [ ] put the data in event.clipboardData
    - [ ] Notion api?

secret_z1CXWiH5SlvxivBpd1ADGBGeFa4xxH3pEFUHGasrrpd

```
curl -X POST 'https://api.notion.com/v1/search' \
  -H 'Authorization: Bearer '"secret_z1CXWiH5SlvxivBpd1ADGBGeFa4xxH3pEFUHGasrrpd"'' \
	-H 'Content-Type: application/json' \
  -H "Notion-Version: 2021-08-16" \
	--data '{
    "query":"a",
    "sort":{
      "direction":"ascending",
      "timestamp":"last_edited_time"
    }
  }'
```

```sh
curl -X POST 'https://api.notion.com/v1/search' \
  -H 'Authorization: Bearer '"secret_z1CXWiH5SlvxivBpd1ADGBGeFa4xxH3pEFUHGasrrpd"'' \
	-H 'Content-Type: application/json' \
  -H "Notion-Version: 2021-08-16" \
	--data '{
    "query":"side",
    "sort":{
      "direction":"ascending",
      "timestamp":"last_edited_time"
    }
  }'
```

```sh
curl 'https://api.notion.com/v1/pages/24247620-04e8-448b-8aa4-aefefe185576' \
  -H 'Notion-Version: 2021-08-16' \
  -H 'Authorization: Bearer '"secret_z1CXWiH5SlvxivBpd1ADGBGeFa4xxH3pEFUHGasrrpd"''
```

```sh
curl -X PATCH 'https://api.notion.com/v1/blocks/3cbff909-f8f2-413f-9ea1-537099c94b10/children' \
  -H 'Authorization: Bearer '"secret_z1CXWiH5SlvxivBpd1ADGBGeFa4xxH3pEFUHGasrrpd"'' \
  -H "Content-Type: application/json" \
  -H "Notion-Version: 2021-08-16" \
  --data '{
	"children": [
		{
			"object": "block",
			"type": "heading_2",
			"heading_2": {
				"text": [{ "type": "text", "text": { "content": "Lacinato kale" } }]
			}
		},
		{
			"object": "block",
			"type": "paragraph",
			"paragraph": {
				"text": [
					{
						"type": "text",
						"text": {
							"content": "Lacinato kale is a variety of kale with a long tradition in Italian cuisine, especially that of Tuscany. It is also known as Tuscan kale, Italian kale, dinosaur kale, kale, flat back kale, palm tree kale, or black Tuscan palm.",
							"link": { "url": "https://en.wikipedia.org/wiki/Lacinato_kale" }
						}
					}
				]
			}
		}
	]
}'
```

- [x] Screen capture on keyboard command
  - [ ] Can take but can't take properly
  - [ ] Use chrome extension to take
    - [ ] Send to a common data store
    - [ ] Have a listner that takes the data
- [ ] Seem like using react to print

## 17 Nov 2021

- [x] Add notion iframe
  - [x] notion.so
  - [x] Problem: Can't embed notion as iframe
    - [x] Probably due to cors
    - [x] Can look into how vivaldi implements side panel
    - [x] Needa just open the website maybe
      - [x] https://dualless.dllplayer.com
      - [x] Seems like it is not possible
    - [x] What about making a custom editor than syncing it on notion
      - [x] https://github.com/JefMari/awesome-wysiwyg
    - [x] Can try this
      - [x] https://github.com/konstantinmuenster/notion-clone/tree/master/frontend
      - [x] But everything store on frontend
- [x] Add video

Notion clone candidates

- https://github.com/konstantinmuenster/notion-clone
- https://github.com/tobi4120/notion-clone
